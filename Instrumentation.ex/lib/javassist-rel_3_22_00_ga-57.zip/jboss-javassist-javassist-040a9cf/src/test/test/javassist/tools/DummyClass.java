package test.javassist.tools;

public class DummyClass {

    @SuppressWarnings("unused")
    private String dummyString = "dummyStringValue";

    public void dummyMethod(){}
}
