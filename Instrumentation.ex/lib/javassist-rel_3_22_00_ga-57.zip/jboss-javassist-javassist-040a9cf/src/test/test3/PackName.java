package test3;

class PackName2 {
    public static int k = 1;
}
public class PackName {
    public static int test3 = 3;
    public static int sub = 4;
    public static int PackName2;

    public static int get() { return test3; }
}
