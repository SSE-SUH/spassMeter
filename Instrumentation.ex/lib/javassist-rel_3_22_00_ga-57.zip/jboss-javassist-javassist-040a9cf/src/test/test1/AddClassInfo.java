package test1;

public class AddClassInfo {
    public int value;
    public int foo() { return 1; }
    public AddClassInfo() { System.out.println("ok"); }
}
