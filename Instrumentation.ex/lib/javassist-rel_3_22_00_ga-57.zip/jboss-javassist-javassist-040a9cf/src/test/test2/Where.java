package test2;

public class Where {
    static int i = 0;
    static String s;
    static {
        String m = "test";
        s = m.substring(1);
    }
}
