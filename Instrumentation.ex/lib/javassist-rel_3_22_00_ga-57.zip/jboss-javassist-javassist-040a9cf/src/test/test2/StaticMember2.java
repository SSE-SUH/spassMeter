package test2;

public class StaticMember2 {
    public static final int f = 11;
    public static final long fj = 13L;
    public static final boolean fb = false;
    public static final double fd = 23.7;

    public static int k = 3;
    public static int seven() { return 7; }
    public int bar() { return 3; }
}
