package test2;

@SuppressWarnings("unused")
public class Nested4 {
    private static int value = 6;
}
